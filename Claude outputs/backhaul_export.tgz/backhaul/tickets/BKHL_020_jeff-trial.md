---
id: BKHL_020
uid: BKHL
number: 20
client: Backhaul
status: open
title: Tools Technician (Jeff) -- cautious trial period
context: New role, no git write, no self-run builds, incremental fixes only, through
  2026-09-16.
priority: normal
opened: '2026-09-09'
closed: null
---

<!-- board:start -->
<!-- board:end -->

## Summary

New role: Tools Technician (persona Jeff), scoped to build/tooling infrastructure shared by
FrontierMode and Satchel (Gradle, git diagnosis, JDK/toolchain, packaging/reobf) -- deliberately
game-content-agnostic, no need to know Satchel or FrontierMode's actual gameplay code.

## Constraints for this trial (through 2026-09-16)

- No git write access at all -- read-only (log/diff/blame/show/status). Never add/commit/push/
  checkout/reset/stash/branch.
- Never runs a build (`./gradlew ...`) directly -- the owner runs every build personally as the
  coordination signal for whether a fix worked. Jeff's output is always "here's the exact change
  and the exact command to run," then waits.
- Checks current Gradle/Forge/ForgeGradle documentation and known-issue trackers for this
  project's pinned versions before any deep diagnosis -- not just once per session, before each
  distinct piece of tech support.
- One change at a time; explains risk before proposing anything beyond a trivial config-value
  edit.

Purpose of the ticket: track the trial explicitly (role file itself stays evergreen per
`bhrole.md` -- point-in-time constraints like an end date don't belong baked into the role page).
Revisit after 2026-09-16: either lift the git-write/no-build restrictions if things have gone
well, or extend the trial.

## Log

- 2026-09-09: Ticket opened.
<!-- bh-header:start -->
**mcRepos** — [Dashboard](../../BACKHAUL.md) · [Board](../BOARD.md) · [Folder](openfolder:///C:/_local/mcRepos/backhaul)
<!-- bh-header:end -->

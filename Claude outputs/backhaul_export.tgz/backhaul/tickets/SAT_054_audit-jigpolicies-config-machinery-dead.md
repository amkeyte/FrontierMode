---
id: SAT_054
uid: SAT
number: 54
client: Satchel
status: open
title: 'Audit JigPolicies/config machinery: dead flags, unwired machinery, and real
  uses'
context: Audit which JigPolicies fields are actually read vs. dead weight -- see body
  for the full tally.
priority: medium
opened: '2026-09-10'
closed: null
---

<!-- board:start -->
<!-- board:end -->

## Summary

Audit JigPolicies/config machinery: dead flags, unwired machinery, and real uses.

## Background

Grew out of the SAT_053 workshop. While tracing exactly which `JigPolicies` fields the
engines actually read (needed to know what SAT_053's redesign was safe to touch),
the honest tally turned out to be small: out of seven policy records, one
(`Lifecycle`) is genuinely load-bearing. Everything else ranges from mostly to
entirely unread:

- `Sync` -- 6 fields (`mode`, `intervalTicks`, `syncOnDirty`, `syncOnTick`,
  `tolerateUnknownBundles`, `tolerateOutOfOrder`) -- **zero** reads anywhere in either
  repo.
- `Errors` -- 4 fields (one per failure mode) -- **zero** reads anywhere.
- `Diagnostics` -- 3 fields, only `enableTracing` read (3 call sites in `ASatchelJig`,
  all just guarding a trace log). `emitLifecycleEvents`/`emitMetrics` unread.
- `Readiness` -- 6 fields, only `.mode()` read (`AScopeCoupler`, `ScopeInfo`). The other
  five (`requiresReadyForAccess/Create/Tick/Sync`, `allowPreReadyBundles`,
  `allowPreReadyAccess`) are unread.
- `Persistence` -- 3 fields, only `.persistent` read (`JigConfigValidator`'s
  cross-check). `.flushOn`/`.missingPolicy` unread -- BorderModule's own comment already
  admits this ("aren't consumed by anything yet").
- `Capabilities` -- **superseded by a same-day correction, see Update below.** First
  cut of SAT_053 made this fully unread (gating moved entirely to a new bundle-level
  `required()`); project owner corrected that same day -- the jig's own allowance and
  the bundle's own requirement are two separate declarations, not one replacing the
  other, and a bundle requiring something its jig doesn't allow now throws. Renamed
  `requiresPersistence/Networking/Clock` -> `allowsPersistence/Networking/Clock` to
  match the corrected meaning. All three fields are read again as of this correction.

## Update 2026-09-10 (same day as opening)

SAT_053 shipped a same-day correction after this ticket was opened: `Capabilities`
(renamed `allowsX`) is confirmed to have a real, ongoing purpose -- the jig's own
declaration of what it supports, checked against the bundle's `required()`, throwing on
mismatch. That settles the existence question for `Capabilities` specifically; it's not
part of this audit's dead-weight pile anymore. What's still open, and still this
ticket's to work out:

- The correction gives the *declare/validate* half of the boss-secrecy motivating case
  below (a bundle can't silently require networking a jig disallows) but not the
  *enforcement* half -- nothing today actually stops a bundle's data from being sent
  just because its jig disallows networking, because the networking axis isn't wired
  into either engine's actual send path yet (only persistence is, per SAT_053). The
  secrecy case still needs that second half designed.
- `Sync`, `Errors`, `Readiness` (5 of 6 fields), `Persistence` (2 of 3 fields),
  `Diagnostics` (2 of 3 fields) are untouched by the correction and remain exactly as
  dead as this ticket originally found them.

None of this is a design failure at the time it was written -- see the project owner's
own framing (SAT_053 discussion, 2026-09-10): `JigPolicies` was built ahead of need, for
a generality (many jigs, many external modules, divergent per-module sync/error/
diagnostics policy) the project hadn't grown into yet when the config layer was built,
and LevelJig -- built as, by the project owner's own description, "the bad example" --
was also the template every other jig was built from, so whatever shape it set
propagated forward by default rather than by re-evaluation.

That doesn't mean the pattern is worthless going forward, though -- see Motivating case
below, which is a concrete counter-example: a real, current need where jig/scope-level
policy (as opposed to the bundle-level `required()` SAT_053 just introduced) looks like
exactly the right layer, not dead weight to prune.

## Motivating case: boss-position secrecy as a jig/scope-level network policy

Project owner's own example (2026-09-10): a boss mob's position is deliberately secret
from the client (already a live constraint -- see FRO_093/FRO_094, `BOSS_JIG`'s
`sideApplicability(SERVER)`, and `boss.md`'s own note on this). The suggested shape: a
`SecureBlockPositionScope`/jig combination with its networking policy set to false, and
the engine wired to simply never send that bundle's data at all -- enforced structurally,
not by trusting every call site to remember not to serialize the secret field.

Why this belongs at jig/scope level and not bundle level: the point being made is that
the *thing being protected* is bigger than any one bundle's own data -- it's about
whether an entire scope's traffic should ever reach the client, which is a statement
about the scope/jig's relationship to the network layer, not a per-bundle capability
declaration like SAT_053's `required()`. **Update 2026-09-10:** `JigPolicies.
Capabilities.allowsNetworking()` (renamed from `requiresNetworking()`) is now confirmed
as the right home for the *declaration* half of this -- a bundle requiring NETWORKING
against a jig that doesn't allow it now throws, the same way persistence does. The
*enforcement* half (actually refusing to send/suppressing traffic for a scope that
disallows networking, not just validating a bundle's own claim) is still unbuilt --
`allowsNetworking()` has no engine-side send-path consumer yet, so this exact protection
still rests entirely on `BOSS_JIG` already being `sideApplicability(SERVER)` (a coarser,
adjacent mechanism) rather than on the capability flag itself. That's this ticket's
remaining piece of the motivating case.

## Scope

Not a cleanup pass -- an audit. For each policy record/field above:

- Confirm current read/no-read status doesn't rely only on this session's greps (spot-
  check with a second pass before drawing conclusions).
- For each **unread** field: is there a real, current or near-term use for it (like the
  secrecy case above), or is it genuinely speculative and safe to remove?
- For each place real behavior exists **without** a checked policy flag driving it
  (the inverse problem -- machinery that runs unconditionally where a policy field
  implies it should be conditional, or a policy field that's set with real intent but
  silently ignored, e.g. BorderModule declaring `flushOn`/`missingPolicy` "so the policy
  reads as intentional" even though nothing reads it) -- decide whether to wire it up or
  remove the false signal.
- Work out the boss-secrecy case's remaining *enforcement* half (see Update above --
  the declare/validate half is done): does `allowsNetworking()` gain a real send-path
  consumer, does `Sync` carry it instead, or does it want its own mechanism entirely.

Explicitly not in scope: touching anything SAT_053 already resolved or is still actively
deciding (bundle-level `required()`, the promotion API, HYDRATED removal) -- this ticket
picks up once that redesign settles, not in parallel with it.

## Not in scope here

Deleting anything yet. Per project owner (2026-09-10): "let's leave the dead weight for
now. It's cheap." This ticket is for finding out what's actually worth keeping/wiring up
before anything gets removed -- deletion, if any, is a later, separate action once the
audit above has an answer.

## Log

- 2026-09-10: PM cleanup -- `context` frontmatter field was far over bht.md's context<=100 guideline (the body already had the full detail, so nothing needed moving); shortened it to a one-line summary.
- 2026-09-10: Same-day correction on SAT_053 (jig `allows` vs. bundle `required()`, see
  Update section above) settled `Capabilities`'s existence question -- narrowed this
  ticket's live scope to: the boss-secrecy case's remaining enforcement half, and the
  still-fully-dead records (`Sync`, `Errors`, most of `Readiness`/`Persistence`/
  `Diagnostics`).
- 2026-09-10: Ticket opened, alongside SAT_053's persistence-axis implementation --
  see SAT_053's "Implemented 2026-09-10" section for the concrete data point
  (`Capabilities` going from 2/3 fields read to 0/3, since superseded same day) that
  prompted filing this now rather than later.
<!-- bh-header:start -->
**mcRepos** — [Dashboard](../../BACKHAUL.md) · [Board](../BOARD.md) · [Folder](openfolder:///C:/_local/mcRepos/Satchel)
<!-- bh-header:end -->

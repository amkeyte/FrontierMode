---
id: BKHL_001
uid: BKHL
number: 1
client: Backhaul
status: done
title: Sandbox mount paths leak into generated links
context: 'See ticket body for full repro/impact. Triage: may be fixed by host_root/BACKHAUL_LOCAL_ROOT.'
priority: high
opened: '2026-08-11'
closed: '2026-08-11'
---

## Summary

Sandbox mount paths leak into generated links

## Full report

[Transferred from Backhaul-self ticket BH_002 -- mcRepos is the live testbed for this class of bug, so reports about the Backhaul CLI/tooling itself get filed here directly under the BKHL namespace instead of routing through the Backhaul repo's own tracker.]

Summary
When a Backhaul project's config.local.json is authored on one machine (e.g. Windows, with content_roots as C:\... paths) but the CLI is invoked from a different execution environment where the same project directory is mounted at a different absolute path (e.g. a Linux container/sandbox with the project mounted at /mnt/...), there's currently no way to run any command that regenerates links -- refresh, dashboard, index -- without corrupting every generated cross-reference link in the project with the sandbox's local path instead of the canonical one.

Background
Backhaul's config has a portability guard: if content_roots paths aren't absolute on the machine currently running the CLI, every command refuses to proceed with a ConfigError ("this usually means the config was written for a different OS/machine ... refusing to proceed rather than silently write to the wrong place or no-op"). That guard is correct and should stay -- but it leaves no supported path forward for the legitimate case where a project's files are genuinely reachable at two different absolute paths from two different execution contexts (host machine vs. a sandboxed/containerized agent session, a WSL mount, a CI runner, etc.) but are the same underlying files.

The only way to get unblocked today is to hand-write a second config with content_roots (and host_root, client_folders) rewritten to whatever path the current execution environment sees. That gets the CLI running, but it has a side effect: every command that regenerates links -- bht refresh/board, bhw refresh/index, bhrm refresh/index, bhrole refresh/index, backhaul dashboard -- derives those links from the same content_roots/host_root values used for file I/O. So the sandbox-local path leaks into:
- openfolder:///... and editmd:///... links in every ticket's/wiki page's/role's bh-header
- The Folder/Edit columns in generated tables (BOARD.md, WIKI_INDEX.md, ROLES_INDEX.md)
- The "This role's project folder is ..." text embedded in each role's generated claude://cowork/new?q=... Launch URL

These links are only valid inside that one sandboxed session. Once the generated files are viewed from the actual host machine (or a fresh session with a different mount path), every one of them is broken.

Steps to reproduce
1. Have a Backhaul project with config.local.json written on Machine A (e.g. Windows), content_roots pointing at C:\Projects\example\backhaul\{tickets,wiki,roadmap,roles}.
2. From Machine/Environment B, where the same project directory is mounted at a different absolute path (e.g. /mnt/example), run any Backhaul command (bht board, bhrm frontier, etc.) using the original config.
3. Observe: command fails immediately with ConfigError: content_roots has path(s) that aren't absolute on this machine.
4. To proceed, write a second config (config.b.json) with content_roots/host_root/client_folders rewritten to Environment B's paths (e.g. /mnt/example/backhaul/...).
5. Run bht refresh (or bhw refresh, bhrm refresh, bhrole refresh, backhaul dashboard) with --config config.b.json.
6. Observe: command succeeds, but every regenerated link in BOARD.md, WIKI_INDEX.md, ROLES_INDEX.md, and every individual ticket/role file's bh-header now contains /mnt/example/... instead of C:\Projects\example\....
7. Repeat step 5 at any later point (even after manually patching the paths back) -- the corruption recurs every time, since it's regenerated fresh from config on every refresh.

Expected behavior
Either:
- The CLI should support specifying the file I/O path and the canonical/display path separately, so a config can say "read and write files at /mnt/example/..., but generate all editmd://, openfolder://, and Launch-URL links using C:\Projects\example\..." -- with the display path defaulting to the content_root path when unset, preserving today's single-machine behavior with zero config changes for the common case.
Or, at minimum:
- Some documented, supported way to run link-regenerating commands from a secondary execution environment without permanently corrupting the project's generated files -- rather than the only escape hatch (a fully-translated config) being one that actively writes wrong data everywhere it touches.

Actual behavior
No supported path exists for this case. The only way to get the CLI running from a secondary environment is a workaround that corrupts every link-bearing generated file, and that corruption reoccurs on every subsequent refresh from that environment -- it's not a one-time fixable event, it's structural to how the config is used.

Impact
Every refresh/dashboard/index run from a secondary environment requires a manual, error-prone find-and-replace pass across every generated file afterward to restore correct paths. In one session working against a real project, this happened three separate times (each triggered by an otherwise-unrelated refresh call), and it's easy to miss a file since the set of affected files isn't obviously enumerable in advance (it's "every file that happens to embed a content_roots- or host_root-derived absolute link," which varies by which sub-commands ran).

Suggested fix
Add an optional display_root (or similarly named) field alongside content_roots/host_root in config.local.json, used exclusively for generating editmd://openfolder:// links and Launch-URL text, distinct from the paths used for actual file reads/writes. Falls back to the existing behavior (display path = content root) when not set, so this is additive and non-breaking.

TRIAGE NOTE (carried over from BH_002, still unresolved): this may already be addressed by host_root (separates display path from content_roots for links) + BACKHAUL_LOCAL_ROOT (separates the I/O path from content_roots, applied before the absolute-path guard) landed in Backhaul tasks #75/#77 -- both already shipped. Likely cause: the reporter's workaround config translated host_root along with content_roots, which defeats host_root's purpose by definition -- host_root is meant to stay pinned to the real machine path regardless of where content_roots resolves. Correct current procedure: leave host_root untouched, redirect I/O only via the BACKHAUL_LOCAL_ROOT env var. Needs review to confirm whether this report predates BACKHAUL_LOCAL_ROOT landing, describes a config that set host_root incorrectly, or is hitting a real remaining gap. No action taken yet -- open only.

## Log

- 2026-09-05: Recurred a third time, new variant: a device-bridge session (mounted at $HOME/mnt/mcRepos, config.local.json still Windows paths) had the BACKHAUL_LOCAL_ROOT export step in its own bootstrap prompt (confirmed present in all 8 mcRepos role files today) but talked itself out of running it, reasoning that the export was a 'sandbox workaround' that wouldn't apply to a device-bridge session specifically. That reasoning is wrong -- the trigger is the path mismatch between the configured Windows content_roots and wherever the CLI actually finds the folder mounted, not the session's connection type -- and was corrected via chat before any command ran. Not a documentation gap this time (the step was right there in the prompt); logging as a trend data point on whether agents rationalizing around this step, rather than simply not finding it, becomes a recurring pattern worth a firmer fix (e.g. wording the step so it can't be read as conditional).
- 2026-08-28: **Recurred, root-caused as a discoverability gap, and fixed structurally.** A
  device-bridge/sandbox session hit this exact failure again — CLI wouldn't run against
  `config.local.json`'s real Windows paths — and, not knowing this ticket or the
  `BACKHAUL_LOCAL_ROOT` fix existed, hand-edited `BOARD.md` directly instead of filing anything.
  Traced why: the fix has been correctly documented in `backhaul/wiki/meta/bhrole.md` since this
  ticket closed, but three of the four role bootstrap prompts (Architect, PM, Game Designer) never
  pointed a session at that page at all, and the fourth (Lead Dev) only gained CLI-install guidance
  this same day, without the `BACKHAUL_LOCAL_ROOT` step. All four role files now carry the export
  step directly in their bootstrap prompts rather than behind a reference a session could skip.
  Also worth noting for the record: the session that hit this tonight initially cited `BKHL_014`
  as the tracked cause of its own failure — that was a misattribution. `BKHL_014` is a real,
  separately-filed bug (default config resolution falling back to the package's own install
  location when `--project`/`--config` are both omitted, tracked upstream as `BH_019`), but it
  isn't this one. Tonight's actual symptom — literal Windows paths in `content_roots` refusing to
  resolve on a non-Windows mount — is this ticket's failure mode, not `BKHL_014`'s.
- 2026-08-11: Ticket opened.
- 2026-08-11: Reformatted to fit BOARD.md's length standard (meta/bht.md) -- original long title/context (which broke the board's markdown table by embedding a full multi-paragraph report and blank lines into a table cell) moved verbatim into this Full report section; title/context frontmatter shortened to match convention.
- 2026-08-11: Triage confirmed by the original reporter (Architect). Root cause was exactly what
  the triage note suspected: the workaround config translated `host_root` along with
  `content_roots`, which defeats `host_root`'s purpose. Retested using the real,
  untouched `config.local.json` (Windows paths, `host_root` unchanged) with
  `BACKHAUL_LOCAL_ROOT=/sessions/.../mnt/mcRepos` exported instead -- ran a full cycle
  (`bhw refresh`, `bhrm refresh`, `bht refresh`, `bhrole refresh`, `backhaul dashboard`) plus both
  `bhrm validate` calls. Zero sandbox-path leaks (repo-wide grep for the sandbox hostname came
  back empty), all `editmd://`/`openfolder://` links and the Launch URL's project-folder text
  correctly show `C:/_local/mcRepos`/`C:\_local\mcRepos`. Confirmed fixed. Closing.
<!-- bh-header:start -->
**mcRepos** — [Dashboard](../../BACKHAUL.md) · [Board](../BOARD.md) · [Folder](openfolder:///C:/_local/mcRepos/backhaul)
<!-- bh-header:end -->

---
id: SAT_053
uid: SAT
number: 53
client: Satchel
status: open
title: Redesign engine-level lifecycle promotion / hydration coupling (SAT_049 root
  cause) + fallout
context: Lifecycle promotion to ACTIVE is wrongly coupled to persistence hydration
  (SAT_049 root cause) -- needs a design pass.
priority: high
opened: '2026-09-09'
closed: null
---

<!-- board:start -->
<!-- board:end -->

## Summary

Lifecycle promotion to ACTIVE is wrongly coupled to persistence hydration (SAT_049 root cause) -- needs a design pass.

## Background

SAT_049 (satchel run tick never actually fires for SatchelHealth's tracker bundles) was
root-caused to: ScopeEngine_Server.hydrateBundle() only calls bundle.hydrateFrom(...) --
the ONLY code path that ever transitions a SatchelBundle out of CREATED (CREATED ->
HYDRATED, then onLoaded() takes it HYDRATED -> LOADED -> ACTIVE) -- when the jig's
JigPolicies.Capabilities declares requiresPersistence(true). Any jig that doesn't need
persistence (SatchelHealth's MOB_JIG/LEVEL_JIG/PLAYER_JIG among them) never gets
hydrateFrom() called at all, so it sits at CREATED permanently. ScopeEngine_Server.onJigTick()
skips any bundle that isn't ACTIVE, so ticking is silently dead for every such bundle,
forever, with no exception and no warning (the RM_SAT_013 stuck-bundle diagnostic is
itself gated behind a different flag, participatesInExecutionPulse, that also isn't set --
two independent silent failures stacked on each other). Full trace is in SAT_049's log
entries.

A targeted patch (always hydrateFrom() an explicitly-empty source when persistence isn't
required, so lifecycle promotion no longer depends on persistence being needed) was
drafted and verified against current code, but was explicitly stopped before shipping.

## The actual problem this ticket is for

Lifecycle promotion to ACTIVE is currently coupled to persistence hydration -- a bundle
can only ever leave CREATED via the same method (hydrateFrom) that's meant for loading
real saved data. That coupling is itself the defect: a jig with no persistence
requirement shouldn't need to go through a "hydrate from nothing" fiction just to become
tickable. This has already recurred once before under a different gap (SAT_027 -- see
the historical note in SatchelBundle.hydrateFrom()'s own javadoc), which suggests the
coupling itself is the wrong shape, not that we keep missing edge cases in an otherwise
correct design.

There's also a live internal contradiction in ScopeEngine_Server's own comments:
resolveServerLevel()'s null-return is documented as "nothing to hydrate, not an error"
(implying skip is safe) while SatchelBundle.hydrateFrom()'s javadoc says "the bundle must
leave CREATED to ever reach ACTIVE" (implying skip is fatal). Both are true as currently
written -- that's the bug.

## Scope

This needs an actual architecture pass on ScopeEngine_Server (and whatever of
ASatchelJig / AScopeCoupler / JigPolicies needs to change alongside it), not a patch:
- What should actually gate a bundle's promotion to ACTIVE, decoupled from whether it
  requires persistence, networking, or clock? (Likely candidates: a dedicated
  "activate"/"ready" step separate from hydration, or splitting "hydration" itself into
  a real optional capability vs. an unconditional lifecycle step.)
- Does participatesInTick vs. participatesInExecutionPulse (two independently-gated
  flags) still make sense once promotion no longer depends on capabilities()? Right now
  a jig can tick without ever running an execution pulse, which is also what silenced
  the RM_SAT_013 stuck-bundle warning for this exact case.
- Fallout: ScopeEngine_Server is a single per-side singleton shared by every jig (see its
  own SAT_023 comment), so whatever shape this lands on affects every jig on it -- not
  just SatchelHealth's. FrontierMode's BorderPregenFixture rides the same engine and
  needs to be checked against whatever the new contract is once designed.
- SAT_049 stays open/parked pointing at this ticket; its root cause is fully understood
  and reproducible, only the fix is deferred here.

## Design

Workshopped 2026-09-10, Dev (Satchel)/Angela with project owner. Conceptual design pass --
no code changed yet. Grounded directly in the current source (ScopeEngine_Server/_Client,
SatchelBundle, LifecycleGuard, AScopeCoupler, ASatchelJig, JigPolicies, SatchelFixture,
FixtureHydrator/FixtureHydrationSource), not just the wiki's description of it.

### Resolved

1. **HYDRATED comes out of `LifecycleState`.** It's never actually an observable resting
   state today -- `onLoaded()` does HYDRATED->LOADED->ACTIVE in one call, with no engine
   pulse ever landing between them. It exists purely as `onLoaded()`'s precondition, and
   that precondition was hardcoded to one specific operation (`hydrateFrom`). New enum:
   `CONSTRUCTED -> CREATED -> LOADED -> ACTIVE -> DESTROYING -> DESTROYED`. Confirmed safe
   to remove by name: `LifecycleState.HYDRATED` is referenced nowhere outside
   `SatchelBundle.java` itself, and `isHydrated()`/the `hydrated` field are read nowhere
   outside the two engines' own one-shot promotion guard -- nothing external treats either
   as a domain signal.
2. **Promotion out of CREATED decouples from any single hardcoded data operation.** A
   bundle carries however many capability-shaped data dependencies it actually has --
   zero, one, or (future) more -- and becomes eligible to promote once all of them report
   satisfied. Zero dependencies (SatchelHealth's trackers, the SAT_049 case) means
   trivially, immediately eligible -- same call as `onCreated()`, mirroring how the
   HYDRATED->LOADED->ACTIVE collapse already behaves today for the one case that works.
3. **Ownership across the three touch points, confirmed non-congruent by design (not a
   bug to fix -- a tenet to keep):**
   - **Jig, Engine** -- hardcoded, Satchel-owned. For this ticket, Engine does the actual
     work: knows which capabilities a bundle's jig declares, knows how to check/satisfy
     each (SavedData today; parcels today; a different backing store or transport later),
     decides when a bundle's dependencies are satisfied, drives the promotion.
   - **Bundle** -- owns its own lifecycle state machine and the fixture fan-out
     (`onCreated`/`onLoaded`/`onJigTick`/`onRemoved`), unchanged in role. Its shape changes
     (no HYDRATED, a generalized promotion entry point) but it still doesn't know or care
     *why* it's allowed to proceed, same as today.
   - **Coupler** -- owns scope-readiness, a genuinely different axis on a genuinely
     different clock (player fully synced vs. merely logged in; a future BlockJig's chunk
     actually loaded vs. ticket-requested; a future `BossMobScopeCoupler` answering "is
     this mob really materialized," not just "does the entity resolve"). Confirmed
     ceremonial today: grepped both repos for `beforeAccess`/`afterAccess`/`beforeCreate`/
     `afterCreate` -- every reference is `AScopeCoupler`'s own permissive default, zero
     subclass overrides anywhere. All six `JigPolicies.Readiness` fields besides `mode`
     (`requiresReadyForAccess`, `requiresReadyForCreate`, `requiresReadyForTick`,
     `requiresReadyForSync`, `allowPreReadyBundles`, `allowPreReadyAccess`) are likewise
     unread anywhere in either repo. Real, available extension point -- explicitly **not**
     touched by this ticket.
   - **Fixture** -- per-instance lifecycle and `isReady()`, already correctly decoupled.
     Confirmed: every real `onLoaded()` override in the tree (`BordersFixture`,
     `BossFixture`, `BossTellFixture`) calls `super.onLoaded()` first, so the base
     `ready = true` always fires once `SatchelBundle` reaches its own `onLoaded()` fan-out.
     `isReady()` is already the live, consumer-facing "is this data trustworthy" signal
     (`BorderAPI`, `RenderContext`, `BossMobFixture`, `BordersInfoFacet` all read it) --
     whatever the new promotion mechanism looks like, it must still end by calling every
     fixture's `onLoaded()` exactly once. Unaffected by this redesign otherwise.
4. **Persistence and networking stop being modeled as the same kind of thing.**
   Persistence is store-shaped -- NBT/SavedData today, with the door held open for a
   different backing store later behind the same source-application contract
   (`FixtureHydrationSource` is already backend-agnostic at the interface level; the bug
   was never in that interface, it was the engine's hardcoded null-check around whether to
   use it at all). Networking is no longer assumed to belong to that same contract going
   forward -- see open question 3. This also keeps the door open for eventually shaping
   *what* gets sent per client rather than replicating a whole bundle to everyone (e.g. a
   registry bundle holding every player who's ever logged in has no business shipping
   whole to every connected client) -- not designed here, just not foreclosed.

### Implemented 2026-09-10 -- persistence axis only, on this branch (revised same day)

Project owner call: stop workshopping open questions 1/2 in the abstract and get the
concrete `ScopeEngine_Server` persistence path actually running, using the bitflag
mechanism settled in discussion (strict/exact bit comparison, not superset) -- while
leaving the networking axis (open question 3) and the full async/polled readiness
mechanism untouched. Shipped, not just designed:

- New `Capability` bitflag enum (`common/bundle/Capability.java`): `PERSISTENCE`,
  `NETWORKING`. `Capability.NONE` (0) is the default.
- `SatchelBundle.required()` -- new, overridable, defaults to `Capability.NONE`. This is
  the bundle-author-declared requirement discussed (deliberately NOT derived from
  jig-level `JigPolicies.Capabilities` -- see Fallout below).
- `LifecycleState.HYDRATED` removed. `hydrateFrom()` no longer performs a lifecycle
  transition (just applies fixture data + sets the `hydrated` flag, guarded by
  `require(CREATED)` instead of `transition(CREATED, HYDRATED)`); `onLoaded()` now
  transitions `CREATED -> LOADED -> ACTIVE` directly.
- `ScopeEngine_Server.hydrateBundle()` rewritten: gates on
  `bundle.required() & Capability.PERSISTENCE.bit()`, not on jig-level
  `caps.requiresPersistence()`. A bundle that doesn't claim `PERSISTENCE` skips hydration
  entirely and promotes straight from CREATED -- this is the literal SAT_049 fix, running
  in code now, not just diagnosed.
- `flushIfDirty()` updated to the same bundle-level gate, for consistency (a bundle that
  never persists shouldn't be flushed to SavedData either).
- `resolveServerLevel()` revised (project owner correction, same day): first cut
  removed the jig-level check entirely, on the theory that "is this required" is fully
  answered by `bundle.required()`. Project owner's actual intent, stated after seeing
  that: **jig offers its own capable policies, bundle handles its own requirements** --
  two separate declarations, not one replacing the other. So `resolveServerLevel()` now
  does two things in sequence: (1) checks `JigPolicies.Capabilities` -- renamed
  `allowsPersistence`/`allowsNetworking`/`allowsClock` (was `requiresX`; the old names
  described the wrong owner and were part of the original conflation) -- and **throws**
  if the jig doesn't declare the capability the bundle is asking for allowed; (2) resolves
  a real `ServerLevel` or throws. A bundle requiring something its own jig doesn't allow
  is a real wiring mistake between the bundle author and the jig author, and it's meant
  to crash loudly at the moment it's discovered -- not a silent skip (the old null-return
  contract) and not silently working anyway.
- `JigConfigValidator`'s existing cross-checks (`allowsPersistence` ⟹
  `persistence.persistent`, `allowsClock` ⟹ tick/executionPulse participation,
  `allowsNetworking` ⟹ `sideApplicability == BOTH`) and `LogicalFoundation`'s boot-time
  RM_SAT_013 health check were updated to the renamed accessors -- no logic changes,
  same checks, honest names.
- `BordersBundle`/`BossBundle` (the two FrontierMode bundles whose jigs declare
  `allowsPersistence(true)`, née `requiresPersistence(true)` -- the rename is accessor-
  only, positional constructor calls in `BorderModule`/`BossModule` are untouched) now
  override `required()` to declare `Capability.PERSISTENCE.bit()` themselves, matching
  what their jig config already asserts. Since both jigs already allow what these
  bundles require, the new crash path never fires for either -- it's a guard rail for a
  future mismatch, not a behavior change for today's two real cases.

**Deliberately not built in this pass:** the general `accumulated == required` strict-
equality check across multiple capability bits, and any async/polled readiness
mechanism. Server-side persistence resolution is synchronous (a SavedData read completes
same-tick), so this slice only needed a single-bit synchronous check. The fuller
mechanism (needed once networking -- inherently asynchronous, parcel-arrival-driven --
gets a `required()` bit of its own) waits on open question 3 below being decided, and on
`ScopeEngine_Client` getting the equivalent treatment `ScopeEngine_Server` just got here
(client bundles that need zero capabilities still have no promotion path today -- see
new note under open question 3).

**Confirms Resolved #2 and #3 empirically, not just in principle:** `BorderPlayerBundle`
(`BORDER_PLAYER_JIG`, explicitly no `capabilities()`/`persistence()` override --
BorderModule's own comment: "not persisted, not networked") and `BossMobBundle`
(`BOSS_MOB_JIG`, same -- no `capabilities()` call at all) were both silently stuck in
CREATED forever under the old code, the exact same failure class as SAT_049's
SatchelHealth trackers -- `BorderModule.onPlayerScopeTick`'s own comment already names
the symptom ("SatchelFixture.onJigTick() is never actually invoked by anything in this
codebase") and works around it with a manual `tellFixture.onJigTick()` call rather than
trusting the dispatch path. Both bundles now promote correctly the moment they're
created, since `required()` correctly defaults to `Capability.NONE` for both. The manual
tick-bypass workarounds these two bundles' fixtures grew are now dead weight worth a
follow-up FrontierMode ticket (not filed here -- Satchel-side fix, FrontierMode cleanup
is a separate client's call).

**Fallout on `JigPolicies.Capabilities` (superseded by the same-day correction above):**
the first cut of this change made `Capabilities` fully unread and was going to be
SAT_054's opening data point. That's no longer true -- `Capabilities` (renamed
`allowsX`) is read again, with a real, clarified purpose: the jig's own declaration of
what it supports, checked against (not replaced by) the bundle's `required()`, with a
thrown exception on mismatch. This settles, for the capabilities axis specifically, the
"is this record worth keeping" question SAT_054 was opened to ask -- see that ticket's
own revision. `Sync`/`Errors`/most of `Readiness`/`Persistence` are unaffected by this
correction and stay exactly as dead as before.

### Also flagged -- housekeeping, not architectural, candidates to remove alongside this
pass rather than step around (all confirmed dead by grep -- zero call sites beyond their
own declaration):
- `common/stitch/PersistStitch.java` -- an earlier per-scope capability-marker attempt at
  the same problem this ticket solves properly, superseded by `JigPolicies.Capabilities`,
  never implemented by any scope, never called.
- `FixtureHydrator.hydrateAllowingCreate()` / `CreateAtHydrateStitch.allowCreateAtHydrate()`
  -- built, wired into `FixtureHydrator`, never implemented by any bundle, never called by
  either engine.
- `JigPolicies.Persistence.flushOn` / `.missingPolicy` fields -- set by BorderModule and
  BossModule (BorderModule's own comment admits "aren't consumed by anything yet"), read
  by nothing. `.persistent` stays real -- `JigConfigValidator` cross-checks it against
  `allowsPersistence` (renamed same day, see Implemented section above).
- `JigConfigValidator`'s two commented-out `//TODO compile hack` cross-checks
  (`ephemeralScopes`, `sync.networkingEnabled()`).

### Open questions -- deliberately not resolved here

1. **How the engine checks whether a bundle's capabilities are ready.** Mechanism TBD.
   Has to work for a dependency that's synchronously available (server persistence:
   SavedData read is always same-tick) and one that's only ever asynchronously available
   (client networking: parcel arrives on a later pulse, if ever), without baking either
   shape into the bundle's own state machine.
2. **The promotion API itself.** Shape TBD -- now explicitly a separate question from (1).
   Constraints it has to satisfy, not a design: (a) still ends by calling every fixture's
   `onLoaded()` exactly once (load-bearing today, see Resolved #3); (b) identical whether a
   bundle has zero dependencies (falls straight through, same call as creation) or one-plus
   (waits on whichever aren't yet satisfied); (c) capability-checking and promotion-
   triggering are no longer required to be the same call.
3. **Does networking gate activation at all, going forward?** Two real options: (a) its
   own independent gate, shaped like persistence's, preserving today's "client waits for
   real server data before considering itself loaded" guarantee; (b) stops gating
   entirely -- a client bundle activates immediately, and the first parcel becomes an
   ordinary post-activation update through the same mechanism (`refreshFrom`-shaped) every
   later parcel already uses. (b) is the fuller application of "networking isn't
   persistence," but it's a real correctness-contract change, not just an internal
   refactor: `onLoaded()` today means "fields hold real values" for a networked bundle,
   and (b) trades that for an eventually-consistent-mirror model. Needs a decision before
   implementation.
4. **`participatesInTick` vs. `participatesInExecutionPulse`.** SatchelHealth's own jig
   configs set `withTick(true)` but never `withExecutionPulse(true)` -- confirmed by
   grep -- which is what let the RM_SAT_013 stuck-bundle health check stay blind to this
   exact failure (the check only runs from inside the engine's `onExecutionPulse`, gated
   by that flag). Fold "make the health check reachable regardless of execution-pulse
   participation" into this pass, or file separately?
5. **Coupler `Readiness` policy fields**, per Resolved #3 -- confirmed unwired, not
   touched by this ticket. Worth a real follow-up once a consumer wants scope-readiness
   gating richer than "always ready" (Boss is the natural first candidate: a
   `BossMobScopeCoupler` answering "is this mob actually materialized").

### Fallout check (from this ticket's own Scope section, above)

- Border and Boss both already declare `requiresPersistence(true)` explicitly -- under
  this design that's a capability dependency that already exists and is already satisfied
  server-side same-tick. Should be a structural no-op for both. Verify once implemented,
  don't assume.
- `ScopeEngine_Server`/`ScopeEngine_Client` stay the single per-side singletons every jig
  shares (SAT_023's own finding) -- whatever shape (1) and (2) above land on has to be
  correct for every jig riding that engine, not special-cased per consumer.

## Not in scope here

The persistence-axis slice above shipped directly on `satchel-53` (project owner call,
2026-09-10) rather than waiting for every open question to close first -- superseded the
original plan to hold all implementation until the full shape was agreed. Still
genuinely not in scope / not done:

- The client-side mirror of today's fix. `ScopeEngine_Client` still has no promotion
  path for a bundle that needs zero capabilities -- `onLoaded()` is only ever called from
  inside `applyIncomingParcels()`, itself only reachable once a real parcel arrives. A
  client bundle declaring `Capability.NONE` would still never promote today. Not touched
  this pass because it's entangled with open question 3 (does networking even gate
  activation going forward) -- fixing the client engine now would mean building it twice.
- Open questions 3, 4, and 5 below, all still open.
- SatchelHealth's own trackers (SAT_049's original bundles) -- not touched by this ticket
  directly; SAT_049 stays parked pointing here, and should close once verified against
  this change in an actual playtest.
- FrontierMode's `ExteriorTellFixture`/`BorderPlayerStatusFixture` manual tick-bypass
  workarounds, now provably unnecessary -- cleanup is FrontierMode's own ticket, not
  filed from here.
- Anything in `JigPolicies`/`JigConfig` beyond what this ticket's own fallout touched --
  routed to SAT_054.

## Log

- 2026-09-10: **Playtest-verified.** debug.log, 13:24:45, clean server stop:

      [Tracking] UNLOADED LevelScope[minecraft:overworld]... TrackerFixture{loads=1, unloads=1, externalTicks=1932, internalTicks=1932}
      [Tracking] UNLOADED LevelScope[minecraft:the_nether]... TrackerFixture{loads=1, unloads=1, externalTicks=1932, internalTicks=1932}
      [Tracking] UNLOADED LevelScope[minecraft:the_end]... TrackerFixture{loads=1, unloads=1, externalTicks=1932, internalTicks=1932}

  `internalTicks == externalTicks` (1932/1932) across all three dimensions -- SatchelHealth's
  LEVEL_JIG tracker (plain `SatchelBundle`, no `capabilities()` override, `required()`
  correctly defaults to `Capability.NONE`) now reaches ACTIVE immediately and ticks every
  single execution pulse, where it previously logged `internalTicks=0` no matter how long the
  session ran (the exact SAT_049 shape -- see that ticket's own 2149-tick/internalTicks=0
  finding). Same instrument, opposite result. This is direct, dated confirmation of the
  actual fix, not just a successful compile. `BorderPlayerBundle`/`BossMobBundle` weren't
  separately instrumented this session (no equivalent log line wired to either -- see
  Implemented section above) but share the identical `Capability.NONE` code path this same
  log line just confirmed, so treating them as fixed by the same mechanism is reasonable, not
  independently proven. The crash path (bundle requires a capability its jig disallows) has
  not been exercised for real -- nothing in the current tree is wired to trigger it, by
  design (Border/Boss's jigs already allow what their bundles require). Closing SAT_049 on
  this evidence; SAT_053 itself stays open (open questions 3-5, client-side networking axis,
  still outstanding).
- 2026-09-10: Build confirmed successful (project owner, actual Gradle build on their own
  machine) -- closes the verification gap the previous log entry flagged (this session's
  device shell had no network to run Gradle itself). Still owed: an actual playtest to
  confirm `BorderPlayerBundle`/`BossMobBundle` now reach ACTIVE and the crash path (bundle
  requires a capability its jig disallows) behaves as intended if ever exercised for real.
- 2026-09-10: Implemented the persistence-axis slice, then revised it same day on
  project owner correction -- see "Implemented 2026-09-10 (revised same day)" above.
  Final shape: `Capability` bitflag enum + `SatchelBundle.required()` (bundle declares
  what it needs), `JigPolicies.Capabilities` renamed `requiresX` -> `allowsX` (jig
  declares what it allows), `ScopeEngine_Server.resolveServerLevel()` checks the bundle's
  requirement against the jig's allowance and throws on mismatch, `HYDRATED` removed
  from `LifecycleState`, `BordersBundle`/`BossBundle` declare their requirement.
  Confirmed (by inspection, not yet playtested) this also fixes
  `BorderPlayerBundle`/`BossMobBundle`'s independent instance of the SAT_049 bug class.
  Could not run an actual Gradle compile in this session (device shell has no network to
  fetch the Gradle distribution) -- changes are grounded in a fresh read of every touched
  file and a full grep for every other call site (`HYDRATED`, `hydrateFrom`,
  `isHydrated`, `CapableOf`, `requiresPersistence`/`requiresNetworking`/`requiresClock`,
  all four real `SatchelBundle` subclasses in the tree), but a real build/playtest
  verification is still owed before this is considered done. Also opened SAT_054 for the
  config-audit follow-up this raised, then revised SAT_054 too once the correction above
  landed.
- 2026-09-10: Design workshop with project owner -- conceptual pass complete, see new
  Design section above. Two questions left deliberately open (capability-readiness check
  mechanism, promotion API shape) pending further discussion before implementation starts.
- 2026-09-09: PM cleanup -- this ticket's `context` frontmatter field was carrying the entire write-up (over bht.md's context<=100 guideline), which broke BOARD.md's table rendering. Moved the full text into a body section verbatim (nothing lost); `context` is now a short summary.
- 2026-09-09: Ticket opened.
<!-- bh-header:start -->
**mcRepos** — [Dashboard](../../BACKHAUL.md) · [Board](../BOARD.md) · [Folder](openfolder:///C:/_local/mcRepos/Satchel)
<!-- bh-header:end -->

---
id: BKHL_021
uid: BKHL
number: 21
client: Backhaul
status: open
title: ticket.md.tmpl doesn't seed bh-header -- lands at file end forever
context: Unlike page.md.tmpl/node.md.tmpl, ticket template has no bh-header markers,
  so refresh_block() appends it at EOF on first run.
priority: normal
opened: '2026-09-10'
closed: null
---

<!-- board:start -->
<!-- board:end -->

## Summary

`ticket.md.tmpl` never seeds `bh-header` markers, so the header block always lands appended
at the literal end of a ticket file instead of staying pinned near the top like every other
content type.

## Root cause (confirmed by reading the installed package's source)

`foundation/markers.py`'s `refresh_block()` is the shared idempotent injector every content
type uses for its `bh-header` block: if the `<!-- bh-header:start/end -->` markers already
exist in the file, it replaces the content between them in place; if they don't exist yet, it
falls back to appending `text + block` -- i.e. onto the literal end of whatever's there.

`services/wiki/templates/page.md.tmpl` and `modules/roadmap/templates/node.md.tmpl` both seed
empty `<!-- bh-header:start -->
**mcRepos** — [Dashboard](../../BACKHAUL.md) · [Board](../BOARD.md) · [Folder](openfolder:///C:/_local/mcRepos/backhaul)
<!-- bh-header:end -->` markers right at the top of the
template. So the very first refresh on a new wiki page or roadmap node finds the markers
already up top and replaces in place -- the header stays pinned at the top forever.

`services/ticket/templates/ticket.md.tmpl` has no `bh-header` markers at all (only an unused,
dead `<!-- board:start -->`/`<!-- board:end -->` pair -- grepped the whole package, nothing
ever reads or writes that marker name). `services/ticket/create.py` renders the ticket body
from that template, then `cli.py`'s `_cmd_open` immediately calls `board.refresh_board_link()`,
which calls the same `refresh_block()`. Since the markers aren't present yet, it takes the
append branch -- onto the end of the freshly rendered body, i.e. after `## Log`. Every
subsequent `bht refresh` then finds the markers exactly there and keeps replacing them in
place -- at the bottom, permanently, for that ticket's whole life.

Not a bug in `refresh_block()` itself -- it's doing exactly what it's supposed to (idempotent,
in-place once found). The gap is specific to `ticket.md.tmpl` not matching the seeding pattern
`page.md.tmpl`/`node.md.tmpl` already establish.

## Fix (drafted, not yet applied -- no push access to this repo from this session)

Bring `ticket.md.tmpl` in line with the other two templates: seed the `bh-header` markers at
the top, and drop the dead `board:start/end` pair. `node.md.tmpl` already carries a second
precedent worth copying too -- an inline HTML comment stating a convention right where someone
editing the template would see it. Applied to tickets, that's a pointer at `bht.md`'s length
guideline (title <= ~40, context <= ~100) sitting right where a ticket gets written, not just
in a wiki page nobody but PM's bootstrap prompt ever points at (see BKHL_020's sibling finding
this same session -- most role bootstrap prompts never told their role bht.md exists either).

Drafted replacement for `services/ticket/templates/ticket.md.tmpl`:

```
<!-- bh-header:start -->
<!-- bh-header:end -->

<!-- See backhaul/wiki/meta/bht.md for ticket conventions: title <= ~40 chars, context <= ~100
     chars -- BOARD.md renders both as table cells. Put real detail in this body (a Summary
     section, your own section, or the Log), not in the frontmatter context field. -->

## Summary

{{ TITLE }}

## Log

- {{ DATE }}: Ticket opened.
```

## Not done here

This session has no push/write access to the Backhaul GitHub repo (no `gh` auth, no configured
git credentials for it) -- confirmed the diagnosis and drafted the exact fix against a scratch
clone, but didn't commit or open a PR. Existing ticket files in mcRepos are unaffected either
way (their header position is already set; this only changes where new tickets land it).

## Log

- 2026-09-10: Ticket opened.

- 2026-09-10: Ticket opened.
<!-- bh-header:start -->
**mcRepos** — [Dashboard](../../BACKHAUL.md) · [Board](../BOARD.md) · [Folder](openfolder:///C:/_local/mcRepos/backhaul)
<!-- bh-header:end -->

---
id: SAT_056
uid: SAT
number: 56
client: Satchel
status: open
title: Document coupler/bundle/fixture/policy extension points from SAT_053
context: Wrote current-state javadoc on Satchel's 4 extension points (coupler, bundle,
  fixture, JigPolicies).
priority: medium
opened: '2026-09-10'
closed: null
---

<!-- board:start -->
<!-- board:end -->

## Summary

Wrote current-state javadoc on Satchel's 4 extension points (coupler, bundle, fixture, JigPolicies).

## Details

SAT_053's workshop named three touch points as owned by different parts of the Satchel architecture on different clocks: Coupler (scope-readiness), Bundle (lifecycle state machine + fixture fan-out), Fixture (per-instance readiness), plus JigPolicies as the declarative layer underneath all of them. Project owner's stated goal: get these out of memory and onto paper so a) FrontierMode can be refactored against them, b) future work can build directly against them, c) it's visible where they can be extended to solve new problems. First pass covers exactly those four files with accurate, current-state javadoc (not historical): JigPolicies.java (class doc plus per-record doc, grounded in SAT_054's field-by-field read/dead audit -- Lifecycle fully load-bearing, Capabilities live again post-correction, Sync/Errors fully dead, Diagnostics/Readiness/Persistence partially dead, each said explicitly rather than implied); ScopeCoupler.java + AScopeCoupler.java (the coupler's eight before/after hooks plus readiness methods, explicit that every hook is confirmed ceremonial today -- zero subclass overrides anywhere -- framed as a real available extension point, not a proven pattern); SatchelBundle.java (class doc plus the four lifecycle hooks onCreated/onLoaded/onJigTick/onDestroyed, each explaining what fires when and the super-call contract); SatchelFixture.java (class doc plus isReady/onCreated/onLoaded/onRemoved/onJigTick, explicitly contrasted with the coupler as the one touch point that's already proven and actively consumed -- BorderAPI, RenderContext, BossMobFixture, BordersInfoFacet all read isReady() today).

## Log

- 2026-09-10: PM cleanup -- this ticket's `context` frontmatter field was carrying the entire write-up (over bht.md's context<=100 guideline, with no Details section in the body at all), which broke BOARD.md's rendering. Moved the full text into a body section verbatim (nothing lost); `context` is now a short summary.
- 2026-09-10: Ticket opened.
- 2026-09-10: First pass complete -- all five files edited (JigPolicies.java,
  ScopeCoupler.java, AScopeCoupler.java, SatchelBundle.java, SatchelFixture.java),
  javadoc-only changes (no behavior touched). Verified each file's brace/paren count
  stayed balanced after editing; not build-verified from this session (same standing
  limitation as every other ticket this session -- no Gradle network access from the
  device shell). Javadoc-only changes carry very low compile risk, but worth confirming
  with a real build or `javadoc` pass before treating this as fully verified, same as
  every other ticket here.
  - Deliberately scoped to exactly the four things named in conversation (policies,
    coupler, bundles, fixtures) -- not the full base-class/interface inventory. A broader
    pass exists as unclaimed follow-up scope: IJigConfigurable, ASatchelJig/SatchelJig,
    ScopeEngine/ScopeInfo/JigInfo, SatchelException (whose class javadoc currently
    undersells its own hierarchy -- says "distinguishes between AccessDenied/AccessFailed"
    when the file actually declares nine subclasses), and PersistStitch (whose javadoc
    describes itself as live/functional but SAT_053 confirms it's superseded by
    Capability/JigPolicies.Capabilities, never implemented by any scope, never called --
    the single clearest case of "historical, not accurate" javadoc found in this codebase
    so far).
  - Also surfaced, not fixed: a batch of comments/javadoc across roughly a dozen files
    (SatchelJig.java, ScopeLifecycleDispatcher.java, PlayerResolver.java, PlayerScope.java,
    JigKey.java, ClientForgeIngress.java, SatchelException.java, others) where the word
    "jig" appears to have been corrupted to "requireJig" by some past find-and-replace --
    e.g. PlayerResolver.java's javadoc literally cites a nonexistent package
    "com.arryn.satchel.common.requireJig.player" (the real package is
    "common.jig.player"). The method name `requireJigInfo()` itself is legitimate
    (require + JigInfo); the corruption is specifically in prose that talks about "the
    requireJig system" or "this requireJig" as if it were a noun. Worth a dedicated sweep,
    separate from this ticket.
<!-- bh-header:start -->
**mcRepos** — [Dashboard](../../BACKHAUL.md) · [Board](../BOARD.md) · [Folder](openfolder:///C:/_local/mcRepos/Satchel)
<!-- bh-header:end -->

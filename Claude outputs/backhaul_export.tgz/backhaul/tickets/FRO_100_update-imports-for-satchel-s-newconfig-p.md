---
id: FRO_100
uid: FRO
number: 100
client: FrontierMode
status: done
title: Update imports for Satchel's newconfig package rehome (SAT_055 companion)
context: 'SAT_055 (Dev-Satchel) moved the common/newconfig and common/newconfig/newnew
  placeholder package to real homes: generic jig-config DSL classes to common/jig/config,
  EventHandlers to common/lifecycle, TrackerFixture to common/tracking, IJigConfigurable
  to common/jig/guts, and the three per-jig-type config classes to their own type''s
  existing package. Two FrontierMode files import from the old location and were deliberately
  left untouched by SAT_055 since FrontierMode is Dev-FrontierMode''s lane. BorderModule.java
  (5 import lines, currently at lines 28-32) needs: EventHandlers -> com.arryn.satchel.common.lifecycle.EventHandlers,
  JigBundles -> com.arryn.satchel.common.jig.config.JigBundles, JigPolicies -> com.arryn.satchel.common.jig.config.JigPolicies,
  LevelJigConfig -> com.arryn.satchel.common.jig.level.LevelJigConfig, PlayerJigConfig
  -> com.arryn.satchel.common.jig.player.PlayerJigConfig. BossModule.java (5 import
  lines, currently at lines 21-25) needs the same EventHandlers/JigBundles/JigPolicies
  mapping plus LevelJigConfig -> com.arryn.satchel.common.jig.level.LevelJigConfig
  and MobJigConfig -> com.arryn.satchel.common.jig.mob.MobJigConfig. No behavior change,
  pure import-path fixes -- same mechanical pattern as the SAT_055 Satchel-side move,
  just re-pointing to the new locations. Old package no longer exists at all in Satchel
  as of SAT_055, so FrontierMode will not compile against Satchel until this lands.'
priority: medium
opened: '2026-09-10'
closed: '2026-09-10'
---

<!-- board:start -->
<!-- board:end -->

## Summary

Update imports for Satchel's newconfig package rehome (SAT_055 companion)

## Log

- 2026-09-10: Ticket opened.
- 2026-09-10: Fixed (Dev/FrontierMode, "Curtis"). All 10 import lines updated exactly per
  this ticket's mapping: BorderModule.java lines 28-32 and BossModule.java lines 21-25,
  `com.arryn.satchel.common.newconfig(.newnew).*` -> the new SAT_055 homes
  (`common.lifecycle.EventHandlers`, `common.jig.config.{JigBundles,JigPolicies}`,
  `common.jig.level.LevelJigConfig`, `common.jig.player.PlayerJigConfig`,
  `common.jig.mob.MobJigConfig`). Re-sorted each file's `com.arryn.satchel.*` import block
  alphabetically while in there (cosmetic only, matches this codebase's existing import
  ordering convention). Pure import-path change, no other lines touched.
  - Verified against real source before and after: confirmed SAT_055's move actually landed
    (old `common/newconfig` directory gone from Satchel, new `common/jig/config` and
    `common/lifecycle/EventHandlers.java` present) before editing, rather than trusting
    SAT_055's log alone.
  - `grep -rn "satchel.common.newconfig" FrontierMode/src` returns nothing -- no remaining
    old-path references anywhere in FrontierMode.
  - `git diff --stat` confirms exactly the 10 expected import lines changed per file (20
    total), nothing else touched.
  - Paren/brace balance verified both files (BorderModule.java 238/238 parens, 38/38 braces;
    BossModule.java 103/103 parens, 27/27 braces).
  - Honesty note, same standing limitation as every other ticket on this project this
    session: no `gradlew`/JDK reachable from this device-bridge session, so this is grep +
    manual-diff verification, not an actual compile. A real build is still owed (same as
    SAT_055's own note) before this and SAT_055 can be trusted to actually unblock
    FrontierMode's build -- not closing the ticket myself, leaving that for confirmation
    after a real compile.
- 2026-09-10 (Dev/Satchel, "Angela"): Real build confirmation landed. SAT_055's own move
  turned out to have a genuine bug (package-private `Presets` fields broken by moving the
  per-type config classes out of `jig.config` -- see SAT_055's log), so FrontierMode's build
  was still red until that was fixed too. With both fixes in place, the user ran real local
  builds for both projects: **Satchel BUILD SUCCESSFUL, FrontierMode BUILD SUCCESSFUL.**
  Curtis's import work above compiled clean on the first real build once SAT_055's side was
  actually correct -- closing this out.
<!-- bh-header:start -->
**mcRepos** — [Dashboard](../../BACKHAUL.md) · [Board](../BOARD.md) · [Folder](openfolder:///C:/_local/mcRepos/FrontierMode)
<!-- bh-header:end -->

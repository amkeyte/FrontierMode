---
id: SAT_055
uid: SAT
number: 55
client: Satchel
status: done
title: Rehome common/newconfig and newconfig/newnew placeholder package
context: 'The newconfig / newconfig.newnew packages were always a placeholder landing
  zone from the 2026-08-13 config-system rollout (see wiki: satchel/architecture/jig-registration-break.md,
  jig-registration-recovery-plan.md) and were never given real homes. A plan for the
  rehome was drafted in another session; this ticket documents and executes it. Target
  shape: generic jig-config DSL classes (JigConfig, CompiledJigConfig, JigBinding,
  JigBindingConfig, JigBundles, JigBundlesConfig, JigConfigCompiler, JigConfigValidator,
  JigExecutionConfig, JigPolicies, JigPoliciesConfig) move to a new common/jig/config/
  package, mirroring the existing common/bundle/builder/ shape. Per-jig-type config
  classes (LevelJigConfig, MobJigConfig, PlayerJigConfig) move into their own type''s
  existing package (common/jig/level, common/jig/mob, common/jig/player). EventHandlers
  moves to common/lifecycle (already home of ScopeEvent, the other event plumbing).
  TrackerFixture moves to common/tracking (home of its sole consumer SatchelHealth).
  IJigConfigurable moves to common/jig/guts (implemented directly by guts classes,
  natural same-package fit). Three classes are confirmed dead on both their own doc
  comments and independent grep and get deleted outright rather than moved: MobTrackingModule,
  PlayerTrackingModule, TrackingModule -- no non-comment references to any of them
  exist anywhere in either repo. Blast radius verified fresh this session (not reused
  from the other session''s plan, which had stale numbers): 15 Satchel files outside
  the newconfig tree import from it (Satchel.java, ClientFoundationBooter, ScopeEngine_Client,
  ASatchelJig, AScopeCoupler, JigInfo, LogicalFoundation, SatchelJig, ScopeCoupler,
  ScopeEngine, ScopeInfo, PlayerResolver javadoc-only, SatchelHealth, ScopeEngine_Server,
  ServerFoundationBooter), plus 2 FrontierMode files (BorderModule.java, BossModule.java
  -- not the other four files the other session''s plan claimed were affected; they
  do not reference newconfig at all).'
priority: medium
opened: '2026-09-10'
closed: '2026-09-10'
---

<!-- board:start -->
<!-- board:end -->

## Summary

Rehome common/newconfig and newconfig/newnew placeholder package

## Scope

File moves (17), package line + all importers updated:

- newconfig/EventHandlers.java -> lifecycle/EventHandlers.java
- newconfig/JigBundles.java -> jig/config/JigBundles.java
- newconfig/TrackerFixture.java -> tracking/TrackerFixture.java
- newconfig/newnew/CompiledJigConfig.java -> jig/config/CompiledJigConfig.java
- newconfig/newnew/JigBinding.java -> jig/config/JigBinding.java
- newconfig/newnew/JigBindingConfig.java -> jig/config/JigBindingConfig.java
- newconfig/newnew/JigBundlesConfig.java -> jig/config/JigBundlesConfig.java
- newconfig/newnew/JigConfig.java -> jig/config/JigConfig.java
- newconfig/newnew/JigConfigCompiler.java -> jig/config/JigConfigCompiler.java
- newconfig/newnew/JigConfigValidator.java -> jig/config/JigConfigValidator.java
- newconfig/newnew/JigExecutionConfig.java -> jig/config/JigExecutionConfig.java
- newconfig/newnew/JigPolicies.java -> jig/config/JigPolicies.java
- newconfig/newnew/JigPoliciesConfig.java -> jig/config/JigPoliciesConfig.java
- newconfig/newnew/IJigConfigurable.java -> jig/guts/IJigConfigurable.java
- newconfig/newnew/LevelJigConfig.java -> jig/level/LevelJigConfig.java
- newconfig/newnew/MobJigConfig.java -> jig/mob/MobJigConfig.java
- newconfig/newnew/PlayerJigConfig.java -> jig/player/PlayerJigConfig.java

Deletions (3, confirmed dead -- own doc comment plus independent grep, zero non-comment references anywhere in either repo):

- newconfig/MobTrackingModule.java
- newconfig/PlayerTrackingModule.java
- newconfig/TrackingModule.java

Then: both now-empty directories (newconfig/, newconfig/newnew/) removed, and a final full-repo grep confirming zero remaining `com.arryn.satchel.common.newconfig` references in Satchel.

Satchel-side import updates land in this ticket (15 files: Satchel.java, ClientFoundationBooter, ScopeEngine_Client, ASatchelJig, AScopeCoupler, JigInfo, LogicalFoundation, SatchelJig, ScopeCoupler, ScopeEngine, ScopeInfo, PlayerResolver, SatchelHealth, ScopeEngine_Server, ServerFoundationBooter).

## Not in scope here

FrontierMode's two importers (BorderModule.java, BossModule.java) are Dev(FrontierMode)'s lane -- companion ticket opened separately with the exact import-line diffs needed, so both sides can land together.

No behavior change intended -- this is a pure rename/move, same as the precedent SAT_004/SAT_007 newstuff->persistence rename. Not folding into SAT_053's remaining open questions (client-side networking axis, coupler Readiness fields) or SAT_054's dead-field audit -- those stay on their own tickets.

## Log

- 2026-09-10: Ticket opened.
- 2026-09-10: Executed the Satchel-side move in this session (device shell against the working tree, no `gradlew` compile available from this session -- see the honesty note below).
  - Moved all 17 files, updated each one's `package` line: EventHandlers -> `common.lifecycle`, JigBundles + the 10 generic DSL classes (CompiledJigConfig, JigBinding, JigBindingConfig, JigBundlesConfig, JigConfig, JigConfigCompiler, JigConfigValidator, JigExecutionConfig, JigPolicies, JigPoliciesConfig) -> new `common.jig.config`, TrackerFixture -> `common.tracking`, IJigConfigurable -> `common.jig.guts`, LevelJigConfig -> `common.jig.level`, MobJigConfig -> `common.jig.mob`, PlayerJigConfig -> `common.jig.player`.
  - Deleted MobTrackingModule.java, PlayerTrackingModule.java, TrackingModule.java outright (confirmed dead by both their own doc comments and a fresh independent grep across both repos -- zero non-comment references to any of the three anywhere).
  - Removed the now-empty `common/newconfig/newnew/` and `common/newconfig/` directories.
  - Fixed every Satchel-side importer (15 files, re-grepped fresh this session rather than trusting the other session's stale ~20-file estimate): Satchel.java, ClientFoundationBooter.java, ScopeEngine_Client.java, ASatchelJig.java, AScopeCoupler.java, JigInfo.java, LogicalFoundation.java, SatchelJig.java, ScopeCoupler.java, ScopeEngine.java, ScopeInfo.java, PlayerResolver.java (javadoc-only reference), SatchelHealth.java, ScopeEngine_Server.java, ServerFoundationBooter.java. Six of these used a `newconfig.newnew.*` wildcard; each was checked by name for actual use of the four classes that moved out of `jig.config` (IJigConfigurable, LevelJigConfig, MobJigConfig, PlayerJigConfig) before assuming the wildcard alone was sufficient -- none of the six needed an extra explicit import (IJigConfigurable lands same-package in every guts-package file that names it; ScopeEngine_Client.java only reaches it transitively through the `ScopeEngine` interface and never names the type directly, so the "needs an explicit IJigConfigurable import" assumption carried over from research before the interruption was wrong and is corrected here).
  - Cleaned up 3 same-package self-imports made redundant by the move (JigBundles.java's import of JigPolicies, JigBundlesConfig.java's import of JigBundles, SatchelHealth.java's import of TrackerFixture) and fixed 1 genuine cross-package import the move introduced (JigExecutionConfig.java's EventHandlers import, since EventHandlers left `jig.config` for `lifecycle` while JigExecutionConfig stayed).
  - Final full-repo grep confirms zero remaining `com.arryn.satchel.common.newconfig` references anywhere in Satchel. FrontierMode's two importers (BorderModule.java, BossModule.java) were deliberately left untouched -- companion ticket below.
  - Spot-checked the two files most recently touched by SAT_053 (JigPolicies.java, JigConfigValidator.java) survived the move with their `allowsX` renames and javadoc intact.
  - Honesty note, same limitation as every other ticket touched this session: `gradlew compileJava` is unreachable from this session (`UnknownHostException: services.gradle.org`, no cached distribution, no network). Verification here is a fresh full-repo grep for the old FQN (clean) plus manual reading of every touched file's import block -- not an actual compile. Recommend a real build before merging, same as SAT_053.
  - Companion ticket for Dev(FrontierMode) opened separately for the two untouched FrontierMode importers.
- 2026-09-10: Real build attempted (user ran `gradlew compileJava` locally, outside this session -- this session's own device shell still can't reach services.gradle.org). Surfaced a genuine bug the manual verification above missed:
  - **Satchel: 87 compile errors**, all "X is not public in Presets; cannot be accessed from outside package," all originating from LevelJigConfig.java/MobJigConfig.java/PlayerJigConfig.java. Root cause: moving these three per-jig-type config classes out of the old single `newconfig.newnew` package and into their own type packages (`jig.level`/`jig.mob`/`jig.player`) broke package-private field access on `JigConfig.Presets` and three of its four sibling `*Config.Presets` nested classes (`JigBundlesConfig.Presets`, `JigPoliciesConfig.Presets`, `JigExecutionConfig.Presets`), which stayed behind in `jig.config`. Before the move everything lived in one package so package-private access silently worked; it was never actually enforcing anything, and the move exposed that. `JigBindingConfig.Presets` was unaffected because its fields were already `public` -- turns out that was the one category that had already paid this cost, inconsistently, before today.
  - Fix: widened the 17 flagged field declarations to `public` across the four Presets classes (`JigConfig.Presets.binding/bundles/policies/execution`; `JigBundlesConfig.Presets.schema`; `JigPoliciesConfig.Presets.enabled/sideApplicability/readiness/sync/persistence/errors/diagnostics/capabilities`; `JigExecutionConfig.Presets.lifecycle/executionPriority/tickOrder/eventHandlers`) -- bringing all four in line with `JigBindingConfig.Presets`'s existing all-public convention rather than inventing a new pattern. `JigConfig.Presets.jigType/scopeType/sourceType` were left untouched -- confirmed those are only ever read from inside JigConfig.java itself, never by the per-type subclasses (which set `p.binding.jigType`, a different field of the same name one level down, not `p.jigType`). Manually cross-checked the fix against the build log's own error breakdown: 24 binding + 21 policies + 12 execution + 3 bundles (the four JigConfig.Presets fields) + 3 each of tickOrder/sync/readiness/persistence/lifecycle/executionPriority/errors/diagnostics/capabilities (the nine category-Presets sub-fields) sums to exactly 87 -- every reported error is accounted for by name. Not re-verified by an actual recompile from this session (still no Gradle network access here); recommend the user re-run the local build to confirm before treating this as closed.
  - **FrontierMode: 71 compile errors**, all "package ... does not exist" / "cannot find symbol" against the old `newconfig` paths in BorderModule.java/BossModule.java. This is the *expected*, already-ticketed breakage (FRO_100) from Satchel's old package genuinely no longer existing -- not a new bug, and not this ticket's to fix.
- 2026-09-10: One more real miss surfaced and fixed alongside the Presets-visibility bug: `common/jig/guts/IJigConfigurable.java` references `CompiledJigConfig` (now in `common.jig.config`) with no import at all -- harmless while both classes shared `newconfig.newnew`, a real "cannot find symbol" once IJigConfigurable moved to `jig.guts` on its own. Fixed with `import com.arryn.satchel.common.jig.config.*;`. Missed in the original move because the earlier verification grepped for stale `newconfig` text, which only catches wrong references, not missing ones -- worth remembering for the next rehome.
- 2026-09-10: User re-ran both builds locally after the Presets-visibility fix. **Satchel: BUILD SUCCESSFUL.** **FrontierMode: also BUILD SUCCESSFUL** -- its two importers (BorderModule.java, BossModule.java) now carry the full corrected import set for the new package layout. That work was done directly against the working tree (not by this session/ticket) and lands as a side effect here rather than through FRO_100's companion-ticket flow; see FRO_100 for the reconciliation note. This ticket's Satchel-side work is now build-verified end to end, not just grep-verified.
<!-- bh-header:start -->
**mcRepos** — [Dashboard](../../BACKHAUL.md) · [Board](../BOARD.md) · [Folder](openfolder:///C:/_local/mcRepos/Satchel)
<!-- bh-header:end -->

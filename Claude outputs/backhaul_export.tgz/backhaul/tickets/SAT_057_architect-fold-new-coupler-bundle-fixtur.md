---
id: SAT_057
uid: SAT
number: 57
client: Satchel
status: open
title: '[Architect] Fold new coupler/bundle/fixture/policy javadoc into the wiki'
context: SAT_056 wrote new javadoc for 4 extension points; needs folding into the
  wiki (Architect's call).
priority: medium
opened: '2026-09-10'
closed: null
---

<!-- board:start -->
<!-- board:end -->

## Summary

[Architect] Fold new coupler/bundle/fixture/policy javadoc into the wiki

## Background

Project owner's own framing (2026-09-10): FrontierMode hasn't used the coupler/bundle/fixture
extension points partly because they may not be useful, but also because they're undocumented
and unprecedented -- there's no established pattern to build against. SAT_056 (Dev-Satchel) is
the "get it out of my head and onto paper" pass: accurate, current-state javadoc (not historical)
on exactly the four touch points named in SAT_053's own ownership split, plus the policy layer
underneath them. Full rationale and diffs are in SAT_056; this ticket is just the wiki-integration
handoff.

## Entries written (SAT_056)

**`common/jig/config/JigPolicies.java`**
- Class-level doc: what this class is (the declarative policy records under `JigPoliciesConfig`)
  and the central honesty point -- most fields are declared, not enforced; see SAT_054's audit.
- `Lifecycle` record: the one fully load-bearing record -- all four fields read, drives
  load/unload/tick/execution-pulse callbacks. Flags that `participatesInTick` and
  `participatesInExecutionPulse` are independent (SatchelHealth's own RM_SAT_013 gap as the
  cautionary example).
- `Readiness` record: only `.mode()` is read; the other five fields (including the two
  `allowPreReady*` and `requiresReadyFor*` families) are unwired. Cross-references `ScopeCoupler`
  as the code-side half of the same gap.
- `Sync` record: fully declarative, zero reads anywhere.
- `Persistence` record: only `.persistent()` is read; `.flushOn()`/`.missingPolicy()` are set by
  real consumers (BorderModule) but read by nothing.
- `Errors` record: fully declarative, zero reads anywhere.
- `Diagnostics` record: only `.enableTracing()` is read (3 call sites in `ASatchelJig`);
  `.emitLifecycleEvents()`/`.emitMetrics()` are unwired.
- (`Capabilities` record already had accurate javadoc from SAT_053 itself -- untouched here.)

**`common/jig/guts/ScopeCoupler.java`** (interface)
- Class-level doc: names this as the "Coupler" touch point from SAT_053's ownership split, states
  plainly that every hook is confirmed ceremonial today (zero overrides in either repo).
- `get`/`ask`/`getOrCreate`: what each does and how they relate (throwing vs. non-throwing vs.
  create-on-demand).
- `markReady`/`tryMarkReady`/`isReady`: what scope-readiness actually is, and that it's distinct
  from `JigPolicies.Readiness.mode()` (which only selects IMMEDIATE vs. DEFERRED).
- `AccessDecision` enum: what ALLOW/DENY actually do to the calling operation.
- All eight hooks (`beforeAccess`/`afterAccess`/`beforeCreate`/`afterCreate`/`beforeTick`/
  `afterTick`/`beforeUnload`/`afterUnload`): what each is called with, what DENY does where
  applicable, and the explicit "unoverridden anywhere as of 2026-09-10" status on each one.
  `beforeAccess`'s doc includes a concrete un-built example (a scope-level access gate for a
  mid-materialization boss mob).

**`common/jig/guts/AScopeCoupler.java`** (abstract class)
- Class-level doc: what this class wires mechanically (engine binding, config, readiness gating,
  lifecycle forwarding) vs. what it leaves as a permissive default, and that the permissive
  defaults are still every real coupler's actual behavior today.
- Comment on the "Hooks (default permissive)" section reinforcing the same point at the
  implementation site.

**`common/bundle/SatchelBundle.java`**
- Class-level doc: names this as the "Bundle" touch point, states its actual scope of ownership
  (its own lifecycle state machine + fixture fan-out) and non-ownership (doesn't know *why* it's
  promoted -- that's the engine, driven by `required()`).
- `onCreated()`/`onLoaded()`/`onJigTick()`/`onDestroyed()`: what state transition each fires, what
  fixture callback it fans out, and the super-call contract for anyone overriding one.

**`common/fixture/SatchelFixture.java`**
- Class-level doc rewritten (was a two-line stub): names this as the "Fixture" touch point, and --
  unlike the other three -- documents it as an already-proven, actively-consumed pattern, not just
  an available one. Names the real consumers of `isReady()` (BorderAPI, RenderContext,
  BossMobFixture, BordersInfoFacet).
- `isReady()`: what it means, when it flips, and that it's the "working half" of Satchel's two
  readiness concepts (contrasted with the coupler's still-unused half).
- `onCreated()`/`onLoaded()`/`onRemoved()`/`onJigTick()`: what fires when, and -- specifically for
  `onLoaded()` -- why every override must call `super` first (the base call is what flips
  `isReady()` true).

## Pointers for wiki placement (Architect's call, not prescribed)

- `bundle.md` and `fixture.md` already exist and are the obvious homes for the bundle/fixture
  material -- worth checking both against SAT_053's own changes (HYDRATED removed from
  `LifecycleState`, `required()`/`Capability` added) while in there, not just the new hook docs,
  since those pages may already be stale on the lifecycle shape itself.
- `runtime.md` already describes the coupler and `JigPolicies` mechanically (how the plumbing
  wires together) but not as documented extension points with usage guidance -- that's the gap
  this ticket closes. Whether that becomes a new `coupler.md`/`policies.md` page or a section
  added to `runtime.md` is a wiki-structure call for the Architect, not decided here.

## Not in scope here

Two things SAT_056 surfaced but didn't touch, noted there for whoever picks them up next (not
this ticket's job, listed here only so they don't get lost): `SatchelException`'s class javadoc
undersells its own hierarchy (says two branches, the file has nine), and `PersistStitch` has
confident-sounding javadoc for a class SAT_053 confirms is dead (superseded by `Capability`,
never implemented, never called) -- a clean example of exactly the "historical, not accurate"
problem this whole effort is about. Also surfaced: a batch of comments across roughly a dozen
files where "jig" appears corrupted to "requireJig" by some past find-and-replace (one file cites
a nonexistent package path). Worth its own pass, separate from wiki integration.

## Log

- 2026-09-10: PM cleanup -- `context` frontmatter field was far over bht.md's context<=100 guideline (the body already had the full detail, so nothing needed moving); shortened it to a one-line summary.
- 2026-09-10: Ticket opened.
<!-- bh-header:start -->
**mcRepos** — [Dashboard](../../BACKHAUL.md) · [Board](../BOARD.md) · [Folder](openfolder:///C:/_local/mcRepos/Satchel)
<!-- bh-header:end -->

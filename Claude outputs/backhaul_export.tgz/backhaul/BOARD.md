<!-- bh-header:start -->
**mcRepos** — [Dashboard](../BACKHAUL.md)
<!-- bh-header:end -->

# Work Board

## open

| Ticket | Client | Pri | Title | Context | Edit |
|---|---|---|---|---|---|
| [BKHL_018](tickets/BKHL_018_role-new-missing-template.md) | Backhaul | normal | bhrole new: missing role.md.tmpl in package | bhrole new crashes: FileNotFoundError, roles/templates/role.md.tmpl not shipped in the installed package. | [Edit](editmd:///C:/_local/mcRepos/backhaul/tickets/BKHL_018_role-new-missing-template.md) |
| [BKHL_019](tickets/BKHL_019_cowork-windows-sandbox-silent-plan9-moun.md) | Backhaul | normal | Cowork Windows sandbox: silent Plan9 mount failure | KB5124008 breaks Hyper-V Plan9 share-attach; VM boots clean but shell has no mounted shares. See ticket body. | [Edit](editmd:///C:/_local/mcRepos/backhaul/tickets/BKHL_019_cowork-windows-sandbox-silent-plan9-moun.md) |
| [BKHL_020](tickets/BKHL_020_jeff-trial.md) | Backhaul | normal | Tools Technician (Jeff) -- cautious trial period | New role, no git write, no self-run builds, incremental fixes only, through 2026-09-16. | [Edit](editmd:///C:/_local/mcRepos/backhaul/tickets/BKHL_020_jeff-trial.md) |
| [BKHL_021](tickets/BKHL_021_ticket-header-bottom.md) | Backhaul | normal | ticket.md.tmpl doesn't seed bh-header -- lands at file end forever | Unlike page.md.tmpl/node.md.tmpl, ticket template has no bh-header markers, so refresh_block() appends it at EOF on first run. | [Edit](editmd:///C:/_local/mcRepos/backhaul/tickets/BKHL_021_ticket-header-bottom.md) |
| [FRO_027](tickets/FRO_027_known-failed-commands-running-list-not-b.md) | FrontierMode | low | Known-failed commands (running list, not being worked) | Running list of border commands found broken by playtest; not being triaged, per owner's call. | [Edit](editmd:///C:/_local/mcRepos/backhaul/tickets/FRO_027_known-failed-commands-running-list-not-b.md) |
| [FRO_031](tickets/FRO_031_betty-donebar.md) | FrontierMode | low | Betty resolved with 2 unconfirmed items | RM_FRO_011's own log leaves an @none tab-complete check and an add-rejection retest unconfirmed. | [Edit](editmd:///C:/_local/mcRepos/backhaul/tickets/FRO_031_betty-donebar.md) |
| [FRO_048](tickets/FRO_048_pathgrow-no-boss.md) | FrontierMode | low | Path grow doesn't create paired boss | [Susan_02] Manual path grow doesn't create a paired boss record, unlike automatic bootstrap grow. | [Edit](editmd:///C:/_local/mcRepos/backhaul/tickets/FRO_048_pathgrow-no-boss.md) |
| [FRO_051](tickets/FRO_051_border-load-count-mismatch.md) | FrontierMode | normal | Border load count: client vs server | [Susan_02] Client BordersFixture load count (1) mismatches server's (0) on same fresh world. | [Edit](editmd:///C:/_local/mcRepos/backhaul/tickets/FRO_051_border-load-count-mismatch.md) |
| [FRO_061](tickets/FRO_061_boss-spawned-selector-delete-despawns-it.md) | FrontierMode | low | Boss: delete despawns its mob | [Susan_02] /boss delete should despawn its mob, not orphan it -- despawn only. See body. | [Edit](editmd:///C:/_local/mcRepos/backhaul/tickets/FRO_061_boss-spawned-selector-delete-despawns-it.md) |
| [FRO_068](tickets/FRO_068_ambient-difficulty-unowned.md) | FrontierMode | normal | Ambient mob difficulty scaling unowned | Design promises normal-mob difficulty scaling; nothing wires layerToDifficulty to mob stats yet. | [Edit](editmd:///C:/_local/mcRepos/backhaul/tickets/FRO_068_ambient-difficulty-unowned.md) |
| [FRO_097](tickets/FRO_097_exterior-design-ready.md) | FrontierMode | normal | New design ready: Exterior (Frontier Sickness, Feral) | Exterior design (Frontier Sickness, Feral) ready. 3 open Qs for Architect -- see Summary. | [Edit](editmd:///C:/_local/mcRepos/backhaul/tickets/FRO_097_exterior-design-ready.md) |
| [FRO_099](tickets/FRO_099_frontier-sickness-core-build.md) | FrontierMode | normal | Frontier Sickness core build | Dev(FrontierMode) build for RM_FRO_037 -- also fixes a live distanceToSurface bug. See body. | [Edit](editmd:///C:/_local/mcRepos/backhaul/tickets/FRO_099_frontier-sickness-core-build.md) |
| [SAT_051](tickets/SAT_051_architect-satchel-health-md-stale-canary.md) | Satchel | normal | [Architect] satchel-health.md stale -- canary/coordinator removed (SAT_050) | [Architect] satchel-health.md still documents the canary/coordinator mechanism SAT_050 removed. | [Edit](editmd:///C:/_local/mcRepos/backhaul/tickets/SAT_051_architect-satchel-health-md-stale-canary.md) |
| [SAT_053](tickets/SAT_053_redesign-engine-level-lifecycle-promotio.md) | Satchel | high | Redesign engine-level lifecycle promotion / hydration coupling (SAT_049 root cause) + fallout | Lifecycle promotion to ACTIVE is wrongly coupled to persistence hydration (SAT_049 root cause) -- needs a design pass. | [Edit](editmd:///C:/_local/mcRepos/backhaul/tickets/SAT_053_redesign-engine-level-lifecycle-promotio.md) |
| [SAT_054](tickets/SAT_054_audit-jigpolicies-config-machinery-dead.md) | Satchel | medium | Audit JigPolicies/config machinery: dead flags, unwired machinery, and real uses | Audit which JigPolicies fields are actually read vs. dead weight -- see body for the full tally. | [Edit](editmd:///C:/_local/mcRepos/backhaul/tickets/SAT_054_audit-jigpolicies-config-machinery-dead.md) |
| [SAT_056](tickets/SAT_056_document-coupler-bundle-fixture-policy-e.md) | Satchel | medium | Document coupler/bundle/fixture/policy extension points from SAT_053 | Wrote current-state javadoc on Satchel's 4 extension points (coupler, bundle, fixture, JigPolicies). | [Edit](editmd:///C:/_local/mcRepos/backhaul/tickets/SAT_056_document-coupler-bundle-fixture-policy-e.md) |
| [SAT_057](tickets/SAT_057_architect-fold-new-coupler-bundle-fixtur.md) | Satchel | medium | [Architect] Fold new coupler/bundle/fixture/policy javadoc into the wiki | SAT_056 wrote new javadoc for 4 extension points; needs folding into the wiki (Architect's call). | [Edit](editmd:///C:/_local/mcRepos/backhaul/tickets/SAT_057_architect-fold-new-coupler-bundle-fixtur.md) |

## in-progress

_No tickets in this state._

## blocked

_No tickets in this state._
